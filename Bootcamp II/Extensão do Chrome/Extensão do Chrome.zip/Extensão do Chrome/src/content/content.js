// Futuro espaço para manipulações diretas na página.
// Exemplo: escutar mensagens do background ou popup.

console.log("Content script carregado: pronto para interações futuras.");

// Exemplo de função utilitária (não usada no momento)
function highlightBody() {
  document.body.style.outline = "3px solid red";
}
